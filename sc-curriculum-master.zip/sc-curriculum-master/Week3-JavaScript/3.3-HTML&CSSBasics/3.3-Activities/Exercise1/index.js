console.log("This message comes from index.js");
