// create a function constructor that works as a template for an Animal
// include properties for name, type, weight, etc.

// create a new instance on an Animal

// add methods to the Animal prototype

// attach a method directly to the Animal instance that "overwrites" a prototype method
