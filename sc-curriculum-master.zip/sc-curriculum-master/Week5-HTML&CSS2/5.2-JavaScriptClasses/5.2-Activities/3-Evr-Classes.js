// refactor your Animal function constructor and methods to use the class keyword

// extend the Animal class with a type of animal
// add some unique methods and properties to the class extension

// create an instance of the class extension and call one of its methods
