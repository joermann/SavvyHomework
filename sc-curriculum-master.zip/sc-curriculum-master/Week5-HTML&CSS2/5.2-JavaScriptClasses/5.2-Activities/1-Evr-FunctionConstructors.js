// create an object literal
// include a method that uses "this"

// create a function in the global scope that prints "this"
