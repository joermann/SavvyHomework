// create a variable "timeOfDay" and assign it a string


// create a variable "greeting" that references a template literal
// use "timeOfDay" in the template literal to create a message like "Good morning!" or "Good evening!"


// print "greeting"


// create a new variable, but do not assign it a value


// print the variable and its type
// ? what type should we expect?


// assign the variable a value that indicates the variable is purposely blank
// ? what value should we assign?


// print the variable and its type again
// ? what type should we expect?


// try to print a variable that does not exist
// ? what should we expect to print in the CLI?


// print "greeting" again
// ? will this line run?

