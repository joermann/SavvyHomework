// create a constant variable (const)


// create a variable that can be reassigned (let)


// create three variables and assign them values of different data types (=)


// print the types of two variables that reference two different data types (typeof)
// TIP: console.log() prints a value in the console/terminal


// change the value referenced by a variable (dynamic typing)


// print the type of the variable you just changed (typeof)


// create variables and give them values to complete the sentences that will print
// ? which variables need to be created?
// ? what type of data needs to go in each variable?



console.log("Hello, my name is " + name + ", and I am learning " + language)
console.log("I have been practicing for only " + weeksOfPractice + " weeks, so my status as a master is: " + masterStatus)
