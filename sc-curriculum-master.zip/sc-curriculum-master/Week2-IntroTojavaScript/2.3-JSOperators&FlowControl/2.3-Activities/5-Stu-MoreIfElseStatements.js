// replace the 1 with different numbers to test different conditions
let num = 1;

// fill in all the parentheses with conditions to log the correct statements

if ( ) {
  console.log("The number is greater than 100.");
} else if ( ) {
  console.log("The number is less than or equal to 40");
} else if ( ) {
  console.log("The number is 42")
} else if ( ) {
  console.log("The number is greater than or equal to 45.")
} else {
  // ? finish the statement with the only three numbers the number could be at this point in the if statement
  console.log("The number is one of these three numbers: , , .")
}