// ? TO DO: create a for loop that TOTALS the numbers from 1 to 100
