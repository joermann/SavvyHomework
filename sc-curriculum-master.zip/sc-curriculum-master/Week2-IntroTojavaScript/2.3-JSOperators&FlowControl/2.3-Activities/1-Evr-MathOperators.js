// ? what should we expect to print?

// basic math
console.log(10 + 5);
console.log(12 - 3);
console.log(15 / 2);
console.log(4 * 5);
console.log(2 ** 3);

// adding/concatenating strings
console.log("10" + "5");
console.log("Hello " + "world");

// modulo (remainder)
console.log(4 % 2);
console.log(5 % 2);
console.log(6 % 2);
console.log(7 % 2);

console.log(6 % 3);
console.log(7 % 3);
console.log(8 % 3);
console.log(9 % 3);
