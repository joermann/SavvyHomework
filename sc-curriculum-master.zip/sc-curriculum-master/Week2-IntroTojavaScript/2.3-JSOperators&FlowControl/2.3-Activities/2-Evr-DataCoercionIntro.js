// ? what should we expect to print?

console.log("2" + 2);
console.log(2 + "2");
console.log(2 + 2);
console.log("2" + "2");
console.log(true + true);
console.log(2 + true);

console.log(true + true + "true" + "false");
console.log(1 + 1 + "2" + "3");
