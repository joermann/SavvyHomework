// ? TO DO: create a while loop that TOTALS the numbers from 1 to 100
// create a variable to represent the current number

// create a variable to represent the current total

// write a while loop that sums the numbers from 1 to 100
