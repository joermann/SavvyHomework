const mathUtilities = require("./mathUtilities");
console.log(mathUtilities.add(1, 2));
console.log(mathUtilities.subtract(5, 2));
