module.exports.add = (a, b) => a + b;
module.exports.subtract = (a, b) => a - b;
