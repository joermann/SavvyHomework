// example, rough-sketch
const apiPromise = new Promise((resolve, reject) => {
  //fetch API data
  if (!data) {
    reject("data not received");
  } else {
    resolve(data);
  }
});
