// select the root node

// select the last child of the root node

// select all the children of the body element

// select the next sibling of the h2 node

// select the parent element of the h1 node
