// create a new unordered list (ul) element

// remove the paragraph element in the nav-bar

// add your new ul element to the nav-bar

// create two new list item (li) elements, and add some text to them

// add the li elements to the ul in the nav-bar
