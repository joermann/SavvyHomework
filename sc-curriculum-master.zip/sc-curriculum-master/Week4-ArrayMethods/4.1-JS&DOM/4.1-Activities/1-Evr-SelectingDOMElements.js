// select all unordered list (ul) elements

// select all elements with the class "class-week"

// select all elements with the class "nav-bar"

// select the element with the id "dog-picture" and save it to a variable
