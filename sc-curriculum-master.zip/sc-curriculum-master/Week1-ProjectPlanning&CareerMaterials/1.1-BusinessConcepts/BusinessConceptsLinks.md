# Business Concepts Materials

## [Business Crash Course v4 Part 1 - PowerPoint slides](https://github.com/JohanBester/sc-curriculum/blob/master/Week1-ProjectPlanning&CareerMaterials/1.1-BusinessConcepts/Business%20Crash%20Course%20v4%20-%20Part%201.pptx?raw=true)

## [Business Crash Course v4 Part 1 - PDF](https://github.com/JohanBester/sc-curriculum/raw/master/Week1-ProjectPlanning%26CareerMaterials/1.1-BusinessConcepts/Business%20Crash%20Course%20v4%20-%20Part%201.pdf)
