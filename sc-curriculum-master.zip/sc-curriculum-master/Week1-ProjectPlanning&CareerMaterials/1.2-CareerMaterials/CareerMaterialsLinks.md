# Career Materials

## [Resume Template](https://docs.google.com/document/d/1_32BH9t4RDXNf4vI_wsZB39Mm1CuTUZujbLEc3AOV-A/edit)

## [Demo Day Outline](https://docs.google.com/document/d/1z-vHWA5hyFjAvVGYIMe7lQMDUV4JCmJmiuURkzgKidk/edit)
